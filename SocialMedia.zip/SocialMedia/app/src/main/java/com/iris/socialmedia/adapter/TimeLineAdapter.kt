package com.iris.socialmedia.adapter

import android.net.Uri
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.iris.socialmedia.R
import com.iris.socialmedia.methodes.Helpers
import com.iris.socialmedia.model.EtatModel
import com.iris.socialmedia.model.PublicationModel
import com.iris.socialmedia.model.UserModel
import com.iris.socialmedia.pages.HomeActivity
import com.iris.socialmedia.pages.PopupOption
import com.iris.socialmedia.repository.EtatRepository
import com.iris.socialmedia.repository.EtatRepository.Singleton.etatData
import com.iris.socialmedia.repository.PublicationRepository
import com.iris.socialmedia.repository.PublicationRepository.Singleton.publicationDataUser
import com.iris.socialmedia.repository.UserRepository.Singleton.id_current_user
import java.text.SimpleDateFormat
import java.util.*

class TimeLineAdapter(
    val context: HomeActivity,
    private val timeLineList: List<PublicationModel>,
    private val layoutId: Int) : RecyclerView.Adapter<TimeLineAdapter.ViewHolder>() {

    val helpers = Helpers()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val timeLineUserImage = view.findViewById<ImageView>(R.id.time_line_user_image)
        val timeLineMoreOption = view.findViewById<ImageView>(R.id.time_line_more_option)
        val timeLineData = view.findViewById<ImageView>(R.id.time_line_data)
        val timeLineFavorite = view.findViewById<ImageView>(R.id.time_line_favorite)
        val timeLineComment = view.findViewById<ImageView>(R.id.time_line_comment)
        val timeLineUsername: TextView? = view.findViewById(R.id.time_line_username)
        val timeLineDate: TextView? = view.findViewById(R.id.time_line_date)
        val timeLineDescription: TextView? = view.findViewById(R.id.time_line_description)
        val timeLineTimeAdd: TextView? = view.findViewById(R.id.time_line_time_add)
        val timeLineTitle: TextView? = view.findViewById(R.id.time_line_title)
        val timeLineFavoriteNumber: TextView? = view.findViewById(R.id.time_line_favorite_number)
        val timeLineCommentNumber: TextView? = view.findViewById(R.id.time_line_comment_number)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(layoutId,parent,false)

        return ViewHolder(view)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // RECUPERER LES DONNEES

        val currentPublication = timeLineList[position]
        val repoPublication = PublicationRepository()
        val repoEtat = EtatRepository()


        if(currentPublication.data != ""){
            Glide.with(context)
                .load(Uri.parse(currentPublication.data))
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.timeLineData)
        }

        repoPublication.getDataUser(currentPublication.id_users){
            if(publicationDataUser.name == "" && publicationDataUser.firstname == ""){
                holder.timeLineUsername?.text = "${publicationDataUser.username}"
            }
            else{
                holder.timeLineUsername?.text = "${publicationDataUser.name}  ${publicationDataUser.firstname}"
            }
            val profileImage = holder.timeLineUserImage
            if(publicationDataUser.profile?.isNotEmpty() == true){
                if (profileImage != null) {
                    Glide.with(context).load(Uri.parse(publicationDataUser.profile)).into(profileImage)
                    helpers.updateCircleImage(profileImage)
                }
            }
        }

        if(repoEtat.countDataFavoriteUser(currentPublication.id,id_current_user!!)){
            holder.timeLineFavorite.setColorFilter(context.resources.getColor(R.color.figma_color_error))
        }else{
            holder.timeLineFavorite.setColorFilter(context.resources.getColor(R.color.black))
        }

      //  Glide.with(context).load(Uri.parse(currentPublication.data)).into(holder.timeLineData)

        if(currentPublication.title?.isNotEmpty() == true){
            holder.timeLineTitle?.text = currentPublication.title
        }else{
            holder.timeLineTitle?.visibility = View.GONE
        }

        if(currentPublication.description?.isNotEmpty() == true){
            holder.timeLineDescription?.text = currentPublication.description
        }else{
            holder.timeLineDescription?.visibility = View.GONE
        }

        val time1 = Calendar.getInstance().time
        val mDate2 = currentPublication.date

        val mDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm")
        val currentTime = mDateFormat.format(time1)
      //  val mDate2F = mDateFormat.format(mDate2.toString())

        val mDate11 = mDateFormat.parse(currentTime)
       // val mDate22 = mDateFormat.parse(mDate2F)

      //  val mDifference = kotlin.math.abs(mDate11.time - mDate2)

     /*   val mDifferenceDates = mDifference / (24 * 60 * 60 * 1000)
        val seconds: Long = mDifferenceDates / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        val days = hours / 24

        val mDayDifference = "${getHours(hours)} ${getMinutes(minutes)}"
*/
        holder.timeLineDate?.text = currentPublication.date

      //  holder.timeLineTimeAdd?.text = ""

        holder.timeLineFavoriteNumber?.text = repoEtat.countDataFavorite(currentPublication.id).toString()

        holder.timeLineCommentNumber?.text = repoEtat.countDataComment(currentPublication.id).toString()

        holder.timeLineFavorite.setOnClickListener {
            var contentValue: String?
            if(repoEtat.countDataFavoriteUser(currentPublication.id,id_current_user!!)){
                holder.timeLineFavorite.setColorFilter(context.resources.getColor(R.color.black))
                contentValue = "unlike"
            }else{
                holder.timeLineFavorite.setColorFilter(context.resources.getColor(R.color.figma_color_error))
                contentValue = "like"
            }

            etatData.id = UUID.randomUUID().toString()
            etatData.publication_id = currentPublication.id
            etatData.user_id = id_current_user!!
            etatData.type = "favorite"
            etatData.content = contentValue

            repoEtat.saveEtatFavoriteUser(currentPublication.id,id_current_user!!,etatData,contentValue)
        }

        holder.timeLineMoreOption.setOnClickListener {
            // afficher la popup
            PopupOption(this, currentPublication).show()
        }

    }

    override fun getItemCount(): Int = timeLineList.size

    private fun getHours(hour: Long) : String {
        return if(hour>0){
            "$hour heure(s)"
        } else{
            ""
        }
    }

    private fun getMinutes(minute: Long) : String {
        return if(minute>0){
            "$minute minute(s)"
        } else{
            ""
        }
    }
}