package com.iris.socialmedia.model

class ContactModel(
    val id:String = "contact0",
    val user_id: String? = "vide",
    val guest_id: String? = "vide",
    val etat: Boolean? = false,
    val date_accept: String? = null
)