package com.iris.socialmedia.model

class PublicationModel(
    var id:String = "publication0",
    var data:String? = null,
    var date:String? = "date",
    var title:String? = "vide",
    var description:String? = "vide",
    var id_users:String = "user0"
)