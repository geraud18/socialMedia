package com.iris.socialmedia.repository

class ContactRepository {
}