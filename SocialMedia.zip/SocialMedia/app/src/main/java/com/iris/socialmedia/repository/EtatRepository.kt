package com.iris.socialmedia.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.iris.socialmedia.model.EtatModel
import com.iris.socialmedia.repository.EtatRepository.Singleton.dataBaseReferenceEtat

class EtatRepository {

    object Singleton {

        val dataBaseReferenceEtat = FirebaseDatabase.getInstance().getReference("etats")
        val dataBaseReferencePublication = FirebaseDatabase.getInstance().getReference("publications")

        val etatList = arrayListOf<EtatModel>()
        var etatData = EtatModel("","","","","")
    }

    fun saveEtatFavoriteUser(publication_id : String, user_id : String, etatModel: EtatModel, content: String){
        var find:Boolean = false
        dataBaseReferenceEtat.addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for(ds in snapshot.children){
                    val etat = ds.getValue(EtatModel::class.java)
                    if(etat != null){
                        if(etat.publication_id == publication_id && etat.type == "favorite" && etat.content != "" && etat.user_id == user_id){
                            find = true
                            val map = mutableMapOf<String, String>()
                            map["content"] = content
                            ds.ref.updateChildren(map as Map<String, Any>)
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        if(!find){
            dataBaseReferenceEtat.child(etatModel.id).setValue(etatModel)
        }
    }

    fun countDataFavoriteUser(publication_id : String, user_id : String): Boolean {
        var find:Boolean = false
        dataBaseReferenceEtat.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                PublicationRepository.Singleton.publicationList.clear()
                for(ds in snapshot.children){
                    val etat = ds.getValue(EtatModel::class.java)
                    if(etat != null){
                        if(etat.publication_id == publication_id && etat.type == "favorite" && etat.content == "like" && etat.user_id == user_id){
                            find = true
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
        return find
    }

    fun countDataFavorite(publication_id : String): Int{
        var count = 0
        dataBaseReferenceEtat.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for(ds in snapshot.children){
                    val etat = ds.getValue(EtatModel::class.java)
                    if(etat != null){
                        if(etat.publication_id == publication_id && etat.type == "favorite" && etat.content == "like"){
                            count++
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        return count
    }

    fun countDataComment(publication_id : String): Int{
        var count = 0
        dataBaseReferenceEtat.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for(ds in snapshot.children){
                    val etat = ds.getValue(EtatModel::class.java)
                    if(etat != null){
                        if(etat.publication_id == publication_id && etat.type == "comment" && etat.content != "like"){
                            count++
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
        return count
    }
}